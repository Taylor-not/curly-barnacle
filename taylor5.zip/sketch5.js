var x = 200;

var y = 200;

var radius = 100;

var screencolorR = 100;

var screencolorG = 0;

var screencolorB = 0;

let button;

function setup() {

	createCanvas(400, 400);

	ellipseMode (RADIUS);

	colorMode (RGB, 255);
   
}



function draw() {

	background (204);

	fill(150, 150, 0);
	
	 ellipse(x, y, radius, radius);

	fill(screencolorR, screencolorG, screencolorB);

	rect (150, 150, 100, 100);
          

}

function mousePressed() {

	var d = dist(mouseX, mouseY, x, y);

	if (d < radius) {

		radius++;

		screencolorR = 50;
		screencolorG = 100;
		screencolorB = 200;

	} else {

		screencolorR = 255;
		screencolorG = 255;
		screencolorB = 25
  

  }
  
  if (keyIsPressed==true);{

  color(200);
  }
}


