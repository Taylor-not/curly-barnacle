let value = 10;

function setup() {

  createCanvas(500, 500)


  strokeWeight(2);

}

function draw() {

  background(220);

  ellipse (40, 40, 50, 50);
   ellipse (460,460,50,50);
  rect (440,20,50,50);
  //for loop, draws a series of boxes

  for (i = 0; i <= 100; i++) {

      rect (i * 1 + 10, i * 10 + 200, i + 20, i + 20);

  }

    if (keyIsPressed) {

        if (key == "b") {

        // fill color for b selected

         fill (255, 140, 100);

        } // close if statement

        else if (key == "z") {

          // fill color for z selected

          fill (255, 0, 0);

        } // close else if stamement

        else if (key == "a") {

          // fill color for z selected

          fill (10, 255, 0);

        } // close else if stamement

        else if (key == "r") {

          // fill color for z selected

          fill (100, 0, 255);

        } // close else if stamement
  }


}

// separate function outside the draw function

function mousePressed() {

  fill (255, 200, 0);

}