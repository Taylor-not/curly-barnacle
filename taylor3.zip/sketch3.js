function setup() {
  createCanvas(128, 128);
  background(220);
}

function draw()
{















}